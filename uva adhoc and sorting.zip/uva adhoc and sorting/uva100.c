#include<stdio.h>
int main()
{
   int i,j,x,n,l,t;
   int sum;
    while((scanf("%d %d",&i,&j))!=EOF)
    {

      if(i>0 && j>0)
      {
              printf("%d %d ",i,j);
            n=0;
            if(i>j)
            {
              t=i;
              i=j;
              j=t;
            }

      for(l=i;l<=j;l++)
      {
        sum=0;
        x=l;
        while(1)
        {
        if(x==1)
            {
          sum++;
          break;
           }
        else if((x%2)==0)
        {
            x=(x/2);
            sum++;
        }
        else
        {
          x=((3*x)+1);
          sum++;
        }
        }
     if(sum>n)
     {
         n=sum;
     }

      }
         printf("%d\n",n);
      }

    }

    return 0;
}
