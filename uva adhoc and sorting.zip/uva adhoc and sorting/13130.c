/*#include<stdio.h>
int main()
{
    long long int n,a[100],i,j,flag,k,l,temp;

    while((scanf("%lld",&n))!=EOF)
    {

        for(j=0;j<n;j++)
        {

        for(i=0;i<5;i++)
        {
            scanf("%lld",&a[i]);
        }


        for(k=0;k<5;k++)
        {
                 for(l=0;l<5;l++)
                {
                    if(a[l]>a[k])
                    {
                       temp=a[k];
                       a[k]=a[l];
                       a[l]=temp;
                    }
                }
        }

        flag=0;

         for(i=0;i<4;i++)
        {

            if((a[i]+1)==a[i+1])
            {
                flag=1;
            }
            else
            {
                flag=0;
                break;
            }
        }

        if(flag==1)
        {
            printf("Y\n");
        }

        else
             printf("N\n");

        }
    }
    return 0;
}
*/

#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,a[5];
    scanf("%d",&n);
    while(n--){
        for(int i=0;i<5;i++){
         scanf("%d",&a[i]);
        }
        if((a[4]-a[0])==4)
            printf("Y\n");
        else
            printf("N\n");
    }
    return 0;
}
