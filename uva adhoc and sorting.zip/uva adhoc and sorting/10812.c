#include<stdio.h>
int main()
{
    int t,a,b,n,sum,y,i;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&a,&b);
        if(a>=b && (a+b)%2==0)
        {
           /* n=((a+b)/2);
            y=n;
            i=a-n;
            sum=y-i;*/
            y=(a+b)/2;
            i=(a-b)/2;
            printf("%d %d\n",y,i);


        }
        else
            printf("impossible\n");


    }
    return 0;
}
