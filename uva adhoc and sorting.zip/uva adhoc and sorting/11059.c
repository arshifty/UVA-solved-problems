
#include<stdio.h>
int main()
{
    long long int a[100],j,sum,t,as,i,k=1,max;

    while((scanf("%lld",&t))!=EOF)
    {
                for(j=0;j<t;j++)
                   {

                       scanf("%lld",&a[j]);

                   }
                   max=0;
                   for(j=0;j<t;j++)
                   {
                       sum=1;
                       for(i=j;i<t;i++)
                       {

                                sum=sum*a[i];
                                if(sum>max)
                                {
                                    max=sum;
                                }
                       }
                   }




                   printf("Case #%lld: The maximum product is %lld.\n\n",k,max);



        k++;
           }


    return 0;

}
