 #include<stdio.h>
 int main()
 {
 int n1,n2,sum,gcd,i,lcd;
    while((scanf("%d %d",&n1,&n2))!=EOF)
    {

        for(i=1;i<=n1 && i<=n2;i++)
        {
            if((n1%i==0) && (n2%i==0))
            {
                gcd=i;
                lcd=(n1*n2)/gcd;


            }
        }
        printf("GCD : %d\n\n",gcd);
        printf("LCD : %d\n\n",lcd);
    }
}
