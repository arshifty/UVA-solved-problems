#include<stdio.h>
int main()
{

    int a,b,c,d,t,e,f,g,h,i;
    while((scanf("%d",&t))!=EOF)
    {
       for(i=1;i<=t;i++)
        {
            scanf("%d:%d %d:%d",&a,&b,&c,&d);
            a=(a*60*60)+(b*60);
            c=(c*60*60)+(d*60);
            scanf("%d:%d %d:%d",&e,&f,&g,&h);
            e=(e*60*60)+(f*60);
            g=(g*60*60)+(h*60);

            if(e>c)
            {
                printf("Case %d: Hits Meeting\n",i);
            }
            else
                 {
                printf("Case %d: Hits Meeting\n",i);
                 }
        }
    }

    return 0;
}
