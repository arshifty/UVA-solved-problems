#include<stdio.h>
int main()
{
   long int n,a[100000],i,sum,add,j,maxi,diff,m,p,temp;

    while((scanf("%ld",&n))!=EOF)
    {
        if(n>=2 && n<=10000)
        {
                    for(i=0;i<n;i++)
        {
            scanf("%ld",&a[i]);
        }
        scanf("%ld",&sum);
        maxi=2000000;

         for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(a[i]>a[j])
                {
                     temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                }
            }
        }

         for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                add=(a[i]+ a[j]);
                        if(sum==add)
                        {
                                        if(a[i]>a[j])
                                        {
                                            diff=a[i]-a[j];
                                        }
                                        else
                                            diff=a[j]-a[i];

                                            if(diff<maxi)
                                            {
                                                maxi=diff;
                                                m=a[i];
                                                p=a[j];
                                            }


                        }
            }
        }
        printf("Peter should buy books whose prices are %ld and %ld.\n\n",m,p);
        }
    }

    return 0;
}

