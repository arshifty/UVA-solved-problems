/*#include<stdio.h>
int main()
{
   int i,j,arr[10],t,n,k,m;
    scanf("%d",&t);

        while(t--)
        {


             int sum0=0,sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0,sum7=0,sum8=0,sum9=0,x;



                            for(x=1,j=1;j<=n;j++)
                            {
                              if(j<=9)
                              {
                                     arr[x]=x;
                                     x++;
                              }


                              else
                              {
                                  int k=j;
                                  while(k!=0)
                                  {
                                      m=k%10;
                                      k=k/10;
                                      arr[x]=m;
                                      x++;
                                  }
                              }

                            }

                            scanf("%d",&n);
                            for(i=1;i<=n;i++)
                            {

                                       if(arr[i]==0)
                                    {
                                        sum0++;
                                    }

                                    else if(arr[i]==1)
                                    {
                                        sum1++;
                                    }
                                    else if(arr[i]==2)
                                    {
                                        sum2++;
                                    }
                                     else if(arr[i]==3)
                                    {
                                        sum3++;
                                    }
                                     else if(arr[i]==4)
                                    {
                                        sum4++;
                                    }
                                     else if(arr[i]==5)
                                    {
                                        sum5++;
                                    }
                                     else if(arr[i]==6)
                                    {
                                        sum6++;
                                    }
                                     else if(arr[i]==7)
                                    {
                                        sum7++;
                                    }
                                     else if(arr[i]==8)
                                    {
                                        sum8++;
                                    }
                                     else if(arr[i]==9)
                                    {
                                        sum9++;
                                    }


                            }
                            printf("%d %d %d %d %d %d %d %d %d %d\n",sum0,sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8,sum9);



    }


    return 0;
}
*/


#include<stdio.h>
int main()
{
   int i,j,arr,t,n,k,m;
    scanf("%d",&t);

        while(t--)
        {


             int sum0=0,sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0,sum7=0,sum8=0,sum9=0,x;


                            scanf("%d",&n);
                            for(i=1;i<=n;i++)
                            {
                                x=i;
                                while(x!=0)
                                {
                                    arr=x%10;

                                    if(arr==0)
                                    {
                                        sum0++;
                                    }

                                    else if(arr==1)
                                    {
                                        sum1++;
                                    }
                                    else if(arr==2)
                                    {
                                        sum2++;
                                    }
                                     else if(arr==3)
                                    {
                                        sum3++;
                                    }
                                     else if(arr==4)
                                    {
                                        sum4++;
                                    }
                                     else if(arr==5)
                                    {
                                        sum5++;
                                    }
                                     else if(arr==6)
                                    {
                                        sum6++;
                                    }
                                     else if(arr==7)
                                    {
                                        sum7++;
                                    }
                                     else if(arr==8)
                                    {
                                        sum8++;
                                    }
                                     else if(arr==9)
                                    {
                                        sum9++;
                                    }
                                    x=x/10;
                                }
                            }
                            printf("%d %d %d %d %d %d %d %d %d %d\n",sum0,sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8,sum9);



    }


    return 0;
}



/*

#include<stdio.h>
int main()
{
    int i,j,k,n,m,a,b,c,d,e,f,g,h,p,q,l,r;
    scanf("%d",&m);
    for(k=1; k<=m; k++)
    {
        a=0;
        b=0;
        c=0;
        d=0;
        e=0;
        f=0;
        g=0;
        h=0;
        p=0;
        q=0;
        scanf("%d",&n);
        for(i=1; i<=n; i++)
        {
            r=i;
            for(j=0 ; ; j++)
            {
                l=r%10;
                if(l==0)
                    a++;
                else if(l==1)
                    b++;
                else if(l==2)
                    c++;
                else if(l==3)
                    d++;
                else if(l==4)
                    e++;
                else if(l==5)
                    f++;
                else if(l==6)
                    g++;
                else if(l==7)
                    h++;
                else if(l==8)
                    p++;
                else if(l==9)
                    q++;

                r=r/10;
                if(r==0)
                    break;
            }

        }
        printf("%d %d %d %d %d %d %d %d %d %d\n",a,b,c,d,e,f,g,h,p,q);
    }
return 0;
}

*/
