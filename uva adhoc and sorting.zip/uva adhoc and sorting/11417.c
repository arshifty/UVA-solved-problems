#include<stdio.h>
int GCD(int n1,int n2)
{
    int i,gcd;
    for(i=1;i<=n1 && i<=n2;i++)
        {
            if((n1%i==0) && (n2%i==0))
            {
                gcd=i;
            }
        }
        return gcd;
}
int main()
{
    int n,sum,gcd,i,j,n1,n2,k;
    while((scanf("%d",&n)))
    {
        sum=0;
        if(n==0)
        {
            break;
        }
        if(n>1 && n<501)
                        {
                            for(i=1;i<n;i++)
                        {
                            for(j=i+1;j<=n;j++)
                            {

                            sum=sum+GCD(i,j);
                            }
                        }
                        printf("%d\n",sum);
                        }
         }



    return 0;

}
   /*
   ////method 1


   int n1,n2,sum,gcd,i;
    while((scanf("%d %d",&n1,&n2))!=EOF)
    {
        for(i=1;i<=n1 && i<=n2;i++)
        {
            if((n1%i==0) && (n2%i==0))
            {
                gcd=i;
            }
        }
        printf("GCD : %d\n\n",gcd);
    }
*/


/*

///method 2
int n1,n2,sum,gcd,i;
 while((scanf("%d %d",&n1,&n2))!=EOF)
 {
     n1=(n1>0)?n1:-n1;
     n2=(n2>0)?n2:-n2;
     while(n1!=n2)
     {
         if(n1>n2)
         {
             n1=n1-n2;
         }
         else
            n2=n2-n1;
     }

       printf("GCD : %d\n\n",n1);
 }
*/
