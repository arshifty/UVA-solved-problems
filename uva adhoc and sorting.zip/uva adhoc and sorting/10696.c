/*
#include<stdio.h>

int  f91(int  a)
{
if(a==0)
    {
        return 0;
    }
    if(a==1)
    {
        return 1;
    }
    int s;
    if(a<=100)
    {
     s=1+f91(a-1);
     return s;
    }

  if(a>=100)
    {
        return (a-10);
    }


}


int main()
{
 int n[100005],t,m;
int i;
for(i=1;i<=250000 ;i++)
{
    scanf("%llu",&n[i]);
    if(n[i]==0)
    {
        break;
    }
}
for(i=1;i<=250000;i++)
{

    if(n[i]!=0 && n[i]>0)
    {
        m=f91(n[i]);
  printf("f91(%llu) = %llu\n",n[i],m);
    }
    else
     return 0;

}
return 0;

}

*/

/*
///try 1
#include<stdio.h>
int add(int  a)
{
if(a==0)
    {
        return 0;
    }
    if(a==1)
    {
        return 1;
    }
    int s;
    if(a<=100)
    {
     s=1+add(a-1);
     return s;
    }

  else
    {
        return (a-10);
    }


}
int main()
{
 int n,t,m;
int i;

    while((scanf("%d",&n)) !=EOF)
    {
        if(n==0)
    {
        break;
    }

    if(n!=0 && n>0)
    {
        m=add(n);
  printf("f91(%d) = %d\n",n,m);
    }
    else
     return 0;
    }
return 0;

}


*/


/*
///step 2
#include<stdio.h>
int main()
{
 int n;
    while((scanf("%d",&n)) !=EOF)
    {
            if(n==0)
        {
            break;
        }

        if(n!=0 && n>0)
        {
                       if(n<=100)
                 {
                      printf("f91(%d) = %d\n",n,n);
                 }
                 else
                 {
                      printf("f91(%d) = %d\n",n,(n-10));
                 }
        }
    }
return 0;

}

*/
/*

step 3
#include<stdio.h>
int add(int  a)
{
if(a<=100)
{
    return a;
}
else
    return (a-10);
}
int main()
{
 int n,t,m;
int i;

    while((scanf("%d",&n)) !=EOF)
    {
        if(n==0)
    {
        break;
    }

    if(n!=0 && n>0)
    {
        m=add(n);
  printf("f91(%d) = %d\n",n,m);
    }
    }
return 0;

}

*/

#include<stdio.h>
int main()
{
    int a,b;
    while(scanf("%d",&a)==1 && a!=0)
    {
        if(a>100)
        {
            b=a-10;
        }
        else
            b=91;
        printf("f91(%d) = %d\n",a,b);
    }
    return 0;
}
