#include<stdio.h>
int main()
{
    char a[100];
    while(gets(a))
    {

        puts(a);
    }
    return 0;
}
