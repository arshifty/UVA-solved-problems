#include<stdio.h>

int main()
{
    long long int a,b,c,n,sum_a_b=1,p;
    int t,sum;
    scanf("%d",&t);
    while(t--)
    {

        sum=0;
        scanf("%lld",&n);
        a=n;
                    while(sum_a_b>0)
                     { b=0;
                         p=a;
                                    while(a>0)
                                    {
                                      c=a%10;
                                      a=a/10;
                                      b=b*10+c;
                                    }


                                       if(p==b)
                                       {

                                           break;
                                       }
                                       else
                                       {
                               sum++;
                               sum_a_b=p+b;
                               a=sum_a_b;
                                       }


                     }
                     printf("%d %lld\n",sum,p);

    }
    return 0;
}
