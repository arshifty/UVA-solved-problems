#include<stdio.h>

int main()
{
    int t1 , t2 , f , a , test1 , test2  ,test3;

    int n,i,c,d;
    while(scanf("%d",&n) ==1)
          {
              for(i=1;i<=n;i++)
                {
                    scanf("%d %d %d %d %d %d %d",&t1,&t2,&f,&a,&test1,&test2,&test3);

        if(test1<=test2 && test1<=test3)
        c=(test2+test3)/2;
        else if(test2<=test1 && test2<=test3)
        c=(test1+test3)/2;
        else if(test3<=test1 && test3<=test2)
        c=(test1+test2)/2;

        d=t1+t2+f+a+c;
        if(d>=90)
        printf("Case %d: A\n",i);
        else if(d>=80)
        printf("Case %d: B\n",i);
        else if(d>=70)
        printf("Case %d: C\n",i);
        else if(d>=60)
        printf("Case %d: D\n",i);
        else if(d<60)
        printf("Case %d: F\n",i);



                }
          }

    return 0;
}
