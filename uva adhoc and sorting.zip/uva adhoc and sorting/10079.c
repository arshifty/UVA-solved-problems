#include<stdio.h>
int main()
{
    long int N,a;

    while((scanf("%ld",&N)) !=EOF)
    {

           if(N<0)
          {
                break;
          }
       if(N>=0)
        {
           a=(N*N+N+2)/2;
        printf("%ld\n",a);
        }


    }
    return 0;
}
