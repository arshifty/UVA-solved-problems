#include<stdio.h>
int main()
{
    int n,i,j;
    while(scanf("%d",&n)!=EOF)
    {

       if(n==1)
        {
             printf("%d is prime\n",n);

        }
        else
        {
            for(i=2;i<n;i++)
        {
            if(n%i==0)
            break;
        }


        if(i==n)
        {
            printf("%d is prime\n",n);

        }
        else
             printf("%d is not prime\n",n);
        }

    }



    return 0;
}
