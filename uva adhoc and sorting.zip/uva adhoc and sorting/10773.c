#include<stdio.h>
#include<math.h>
int main()
{

   double d,u,v,c,t1,t2;
     int i=1,t;
     scanf("%d",&t);
    while(t--)
    {



        scanf("%lf %lf %lf",&d,&v,&u);
        if(v==0 || u==0 || v>=u)
       {
        printf("Case %d: can't determine\n",i++);

       }
        else
        {
            t1=d/u;
            t2=d/sqrt(u*u-v*v);
            c=t2-t1;
            printf("Case %d: %.3lf\n",i++,c);
        }



    }


    return 0;
}
