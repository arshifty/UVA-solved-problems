#include<stdio.h>
int main()
{
    int t,n,a[100],i,j,sumtall,sumsmall;
    scanf("%d",&j);
    for(t=1;t<=j;t++)
    {
        sumtall=0;
        sumsmall=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }

        for(i=0;i<n-1;i++)
        {
          if(a[i]<a[i+1])
          {
              sumtall+=1;
          }
          if(a[i]>a[i+1])
          {
              sumsmall+=1;
          }
        }

        printf("Case %d: %d %d\n",t,sumtall,sumsmall);


    }



    return 0;
}
