#include<stdio.h>
int main()
{

    long long int a,b,mod1,mod2,r,i,t;
    int sum;

while((scanf("%lld %lld",&a,&b))!=EOF)
{
     if(a==0 && b==0)
        {
            break;
        }
        r=0;
        sum=0;

        while(a!=0 || b!=0)
        {
            mod1=a%10;
            a=a/10;

            mod2=b%10;
            b=b/10;

            r=(mod1+mod2)+r;
            if(r>=10)
            {
                sum=sum+1;
                r=r/10;
            }
            else
            {
                r=0;
            }

        }
            if(sum==0)
            printf("No carry operation.\n");
            else if(sum==1)
            printf("%d carry operation.\n",sum);
            else if(sum>1)
            printf("%d carry operations.\n",sum);



    }

    return 0;
}
