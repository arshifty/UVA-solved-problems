#include<stdio.h>
#include<math.h>

int main()
{
    long int x,sum,i,p;

   while((scanf("%ld",&x))!=EOF)
    {

        sum=0;
        for(i=1;i<=x;i++)
        {
            p=i*i*i;
            sum+=p;
        }
        printf("%ld\n",sum);

    }

    return 0;
}
