#include<stdio.h>
int main()
{

    int cd,cm,cy,bd,bm,by,d,m,y,t,l;
    char c1,c2,c3,c4;
    while(scanf("%d",&t) ==1)
     {

             if(t>=1 && t <=200)
    {
      for(l=1;l<=t;l++)
    {



    scanf("%d/%d/%d",&cd,&cm,&cy);
    scanf("%d/%d/%d",&bd,&bm,&by);



    d=cd-bd;

    if(cd<bd)
    {
        d=(cd+30)-bd;
        m=cm-(bm+1);

        if(cm<(bm+1))
        {
            m=(cm+12)-(bm+1);
            y=cy-(by+1);

        }

        else
        {
            y=cy-by;


        }

    }

    else
    {
        m=cm-bm;

        if(cm<bm)
        {
            m=(cm+12)-bm;
            y=cy-(by+1);


        }
        else
        {
            y=cy-by;

        }
    }
    if(y<0)
    {
     printf("Case #%d: Invalid birth date\n",l);

    }

    else if(y>130)
    {
        printf("Case #%d: Check birth date\n",l);
    }
    else
        {
        printf("Case #%d: %d\n",l,y);
        }

    }
    }
     }


    return 0;
}
