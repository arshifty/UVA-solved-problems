#include<stdio.h>
int main()
{
   long long int a,b,result,k=1;

    while((scanf("%lld %lld",&a,&b))!=EOF)
    {

     if(a==0 && b==0)
     {
         break;
     }

     else
     {

                 result=(a-1)/b;
                 if(result>26)
                 {
                     printf("Case %lld: impossible\n",k);
                     k++;
                 }
                 else
                   {
                        printf("Case %lld: %lld\n",k,result);
                        k++;
                   }
     }

    }
    return 0;
}
