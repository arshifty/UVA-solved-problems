#include<stdio.h>
int main()
{

    double c,d,r,t,f;
    int i,n;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
            scanf("%lf %lf",&c,&d);
            f=((9*c)/5)+d;
            c=(5*(f-d))/9;

        printf("Case %d: %.2lf\n",i,c);
    }

    return 0;
}
