#include<stdio.h>
#include<string.h>
int main()
{
    char s[1000];
    int m4,i;
    while(scanf("%s",&s)!=EOF)
    {
        if(s==0)
        {
            break;
        }
        int len=strlen(s);
        m4=0;
       for(i=0;i<len;i++)
       {
            m4=(m4*10+s[i]-'0')%17;

       }
       if(m4==0 && len==1)
        break;
       if(m4==0)
       {
            printf("1\n");
       }
       else
        printf("0\n");
    }
    return 0;
}
