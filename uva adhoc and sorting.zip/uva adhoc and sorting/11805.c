#include<stdio.h>
int main()
{
    int t,n,k,p,sum,i;
    scanf("%d",&t);
    if(t<=1000)
    {
        for(i=1;i<=t;i++)
    {
        scanf("%d %d %d",&n,&k,&p);
        sum=k+p;
        while(sum>n)
        {
            sum=sum-n;
        }
        printf("Case %d: %d\n",i,sum);
    }
    }

    return 0;
}
