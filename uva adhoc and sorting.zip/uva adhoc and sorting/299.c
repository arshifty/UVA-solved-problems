#include<stdio.h>
int main()
{
    int n,l,i,sum,a[100],j,temp,p;
    scanf("%d",&n);
    while(n--)
    {
        scanf("%d",&l);
        p=l;
        if(p>=0 && p<=50)
       {
        for(i=0;i<p;i++)
        {
        scanf("%d",&a[i]);
        }
        sum=0;
        for(i=0;i<p;i++)
        {
            for(j=i+1;j<(p/2);j++)
            {
                if(a[i]>a[j])
                {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                    sum+=1;
                }
            }

        }
        printf("Optimal train swapping takes %d swaps.\n",sum);


    }
    }

    return 0;
}
