#include<stdio.h>
int main()
{
    long long int a,b,sum;
    while((scanf("%lld %lld",&a,&b))!=EOF)
    {
        if(a==-1 && b==-1)
        {
            break;
        }

       if(a>=0 && b<=99)
       {
         if(a<b)
        {
             sum=b-a;

        }
        else
        {
         sum=a-b;

        }
        if(sum>=50)
        {
            sum=100-sum;
        }
        printf("%d\n",sum);
       }
    }
    return 0;
}
