#include<stdio.h>
int main()
{
    int mile=0,juice=0,i,a[1000],b[1000],t,n,j;
    while((scanf("%d",&t))!=EOF)
    {

        for(i=1;i<=t;i++)
        {
             mile=0;
             juice=0;
                        scanf("%d",&n);
                        for(j=0;j<n;j++)
                        {

                                scanf("%d",&a[j]);
                                b[j]=a[j];

                                 if(a[j]<30)
                                 {
                                     mile+=10;
                                 }

                                 else
                                 {
                                    int div=a[j]/30;
                                     int tt=div+1;
                                     mile=mile+(10*tt);
                                 }

                                 if(b[j]<60)
                                 {
                                     juice+=15;
                                 }

                                 else
                                 {
                                     int div=b[j]/60;

                                     int tt=div+1;
                                     juice=juice+(15*tt);
                                 }






                        }


            if(juice>mile)
            {
                printf("Case %d: Mile %d\n",i,mile);
            }
            if(juice<mile)
            {
                printf("Case %d: Juice %d\n",i,juice);
            }
            if(juice==mile)
            {
                printf("Case %d: Mile Juice %d\n",i,mile);
            }

        }


    }


    return 0;
}
