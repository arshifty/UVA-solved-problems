#include<stdio.h>
int main()
{

    int n;
    int a,b,c,i;
    while(scanf("%d",&n)!=EOF)
    {
        if(n==0)
            break;
        else
        {
             a=0;
             b=1;
            for(i=1;i<=n;i++)
            {

                c=a+b;
                a=b;
                b=c;

            }
             printf("%d\n",b);
        }
    }



    return 0;
}
