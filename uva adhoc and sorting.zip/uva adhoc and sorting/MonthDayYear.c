#include<stdio.h>
#include<conio.h>

int main()
{
    int days ,months,year,week;
    printf("enter the days: \n");
    scanf("%d",&days);
    year=days/365;
    week=days/7;
    months=days/30;
    days=days%30;
    printf("%d %d %d %d\n",year,week,months,days);

return 0;
}
