
#include<stdio.h>
#include<string.h>
int main()
{
    char ch,a[100];

    int tt,ss,sum,o;
     int i;
    while((scanf("%d",&tt))!=EOF)
    {

        o=1;
 while(o<=tt)
{


    gets(a);
    int len=strlen(a);
    if(len==0) continue;
     sum=0;

    for(i=0;i<len;i++)
    {
        if(a[i]=='a' || a[i]=='d' || a[i]=='g' || a[i]=='j' || a[i]=='m' || a[i]=='p' || a[i]=='t' || a[i]=='w' || a[i]==' ')
        {
            sum++;
        }
        if(a[i]=='b' || a[i]=='e' || a[i]=='h' || a[i]=='k' || a[i]=='n' || a[i]=='q' || a[i]=='u' || a[i]=='x')
        {
            sum=sum+2;
        }
        if(a[i]=='c' || a[i]=='f' || a[i]=='i' || a[i]=='l' || a[i]=='o' || a[i]=='r' || a[i]=='v' || a[i]=='y')
        {
            sum=sum+3;
        }
        if(a[i]=='s' || a[i]=='z')
        {
            sum=sum+4;
        }
    }

            printf("Case #%d: %d\n",o,sum);
            o++;
        }
    }
    return 0;
}

