/*
#include<stdio.h>
int main()
{
    int a,b,c;
    while((scanf("%d %d",&a,&b)) !=EOF)
    {
       int c;
       c=a-b;
       printf("%d\n",c);
    }
    return 0;
}
*/
/*
///step 2
#include<stdio.h>
int main()
{
    int a,b,c;
    while((scanf("%d %d",&a,&b)) !=EOF)
    {
       int c;
       c=b-a;
       printf("%d\n",c);
    }
    return 0;
}
*/
/*
///step 3
#include<stdio.h>
int main()
{
    int a,b,c;
    while((scanf("%d %d",&a,&b)) !=EOF)
    {
        int c;
        if(a>b)
       {
           c=a-b;
           printf("%d\n",c);
       }
       else
         printf("%d\n",b-a);
    }
    return 0;
}
*/

/*
///step 4
#include<stdio.h>
int main()
{
    int a,b,c;
    while((scanf("%d %d",&a,&b)) !=EOF)
    {
        int c,t;

        if(a>b)
       {
           c=a-b;
           printf("%d\n",c);
       }
      if(b>a)
      {
          t=a;
          a=b;
          b=t;
          c=a-b;
          printf("%d\n",c);
      }
    }
    return 0;
}
*/
#include<stdio.h>
int main()
{
   long long int a,b,c;
    while((scanf("%lld %lld",&a,&b)) !=EOF)
    {

        if(a>b)
          {
               c=a-b;
          }
          else
           {
                c=b-a;
           }
         printf("%lld\n",c);
    }
    return 0;
}
