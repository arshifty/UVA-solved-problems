#include<stdio.h>
#include<math.h>
int main()
{
    long long  t,n,sum,i,j;

     scanf("%lld",&t);

       for(j=1;j<=t;j++)
        {
            scanf("%lld",&n);

                  sum=(-1+sqrt(1+8*n))/2;
                    printf("%lld\n",sum);

        }


    return 0;
}
