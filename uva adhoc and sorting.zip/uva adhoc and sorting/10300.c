#include<stdio.h>
int main()
{
    int t,nf,sm,an,ef,sum=0,ml,i;
    scanf("%d",&t);
    if(t<20)
    {
        while(t--)
    {
        while((scanf("%d",&nf))!=EOF)
        if(nf>0 && nf <20)
       {
            for(i=1;i<=nf;i++)
        {
            scanf("%d %d %d",&sm,&an,&ef);
             if(sm>0 && an >0 && ef>0)
           {
            ml=sm*ef;
            sum=sum+ml;
           }
        }
        printf("%d\n",sum);
        sum=0;
       }
    }
    }
    return 0;
}
