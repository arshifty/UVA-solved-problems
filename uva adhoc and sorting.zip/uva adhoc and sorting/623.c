/*

#include<stdio.h>
int main()
{


int t;
    int a[500]; //array will have the capacity to store 200 digits.
    int n,i,j,temp,m,x;

    scanf("%d",&t);
    while(t--)
    {
       scanf("%d",&n);
       a[0]=1;  //initializes array with only 1 digit, the digit 1.
       m=1;    // initializes digit counter

       temp = 0; //Initializes carry variable to 0.
       for(i=1;i<=n;i++)
       {
            for(j=0;j<m;j++)
            {
               x = a[j]*i+temp; //x contains the digit by digit product

               printf("x : = %d\n",x);
               a[j]=x%10; //Contains the digit to store in position j
               printf("a[%d] = %d\n",j,a[j]);
               temp = x/10; //Contains the carry value that will be stored on later indexes
                printf("temp : %d\n",temp);
            }

             printf("see inside while loop\n\n");
             while(temp>0) //while loop that will store the carry value on array.
             {
               a[m]=temp%10;
                printf("a[%d] : %d\n",m,a[m]);
               temp = temp/10;
                printf("temp : %d\n",temp);
               m++; // increments digit counter
                printf("m= : %d\n",m);
             }
              printf("\n\n");
      }

       printf("\n\nfactorial : ");
              for(i=m-1;i>=0;i--) //printing answer
              printf("%d",a[i]);
              printf("\n");
    }
    return 0;
}
*/

#include<stdio.h>
int main()
{
    int a[3000],i,j,t,n,temp;

    while((scanf("%d",&n))!=EOF)
    {


        a[0]=1;
        int temp=0;
        int m=1;
        for(i=1;i<=n;i++)
        {

            for(j=0;j<m;j++)
            {
                int x=a[j]*i+temp;
                a[j]=x%10;
                temp=x/10;
            }

            while(temp>0)
            {
                a[m]=temp%10;
                temp=temp/10;
                m++;
            }



        }



         printf("%d!\n",n);
        for(i=m-1;i>=0;i--)
        {
            printf("%d",a[i]);

        }
         printf("\n");

    }


    return 0;
}
