#include<stdio.h>
#include<string.h>
int main()
{

    char a[100]="`1234567890-=QWERTYUIOP[]\ASDFGHJKL;'ZXCVBNM,./";
    int i,len=0,j;
    char ch,s[100],str[100];
     len=strlen(a);


   while(gets(s))
   {
       int s_length=strlen(s);

       if(s_length==0)
        continue;

        for(j=0;j<s_length;j++)
        {
                for(i=0;i<len;i++)
                          {
                                if(s[j]==a[i])
                                {
                                    str[j]=a[i-1];
                                }
                                if(s[j]==' ')
                                {
                                    str[j]=' ';
                                }
                          }
        }

    for(j=0;j<s_length;j++)
        {
            printf("%c",str[j]);
        }
        printf("\n");
   }

    return 0;
}
