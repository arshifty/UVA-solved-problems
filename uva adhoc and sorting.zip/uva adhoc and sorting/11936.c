#include<stdio.h>
int main()
{
    int a,b,c,t;
    while((scanf("%d",&t))!=EOF)
    {

       while(t--)
       {
            scanf("%d %d %d",&a,&b,&c);
        int sum=a+b;
        if(sum>c)
        {
            printf("OK\n");
        }
        else
        {
           printf("Wrong!!\n");
        }
       }
    }


    return 0;

}
