#include<stdio.h>
int main()
{
    int a,b,i,j=1;
    int sum;
    int T;
    scanf("%d",&T);
    if(T>=1 && T<=100)
    {
        while(T--)
    {
        sum=0;
    scanf("%d%d",&a,&b);
    if( (a>=0 && a <=b) && (b>=a && 100))
    {
        for(i=a;i<=b;i++)
        {
            if((i%2)!=0)
            {
                sum+=i;
            }
        }
    }
    printf("Case %d: %d\n",j,sum);
    j++;
}
    }
    return 0;
}
