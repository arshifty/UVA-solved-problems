#include<stdio.h>
#include<string.h>
int main()
{
    char s[1000];
    int m4,i;
    while(scanf("%s",&s)!=EOF)
    {

        int len=strlen(s);
        m4=0;
       for(i=0;i<len;i++)
       {
            m4=(m4*10+s[i]-'0')%11;

       }
       if(m4==0 && len==1)
        break;
       if(m4==0)
       {
            printf("%s is a multiple of 11.\n",s);
       }
       else
         printf("%s is not a multiple of 11.\n",s);
    }
    return 0;
}
