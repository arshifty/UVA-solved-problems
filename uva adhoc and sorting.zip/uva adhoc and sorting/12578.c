#include<stdio.h>
#include<math.h>
#define PI acos(-1)
int main()
{
    int t;
    double rec_area,cir,r,w,rec,l;
    while((scanf("%d",&t))!=EOF)
    {
       while(t--)
       {
        scanf("%lf",&l);

            w=(l*6)/10;

        r=(l*2)/10;
        cir=(PI*r*r);

        rec=l*w;
        rec_area=rec-cir;
        printf("%.2lf %.2lf\n",cir,rec_area);
        }




    }

    return 0;
}


