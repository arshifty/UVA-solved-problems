#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
    string s;
    int k=1;
    while(cin>>s)
    {
        if(s=="*")
        {
            break;
        }
        if(s=="Hajj")
        {
            printf("Case %d: Hajj-e-Akbar\n",k);
            k++;
        }
        else
        {
            printf("Case %d: Hajj-e-Asghar\n",k);
            k++;
        }
    }


    return 0;
}
