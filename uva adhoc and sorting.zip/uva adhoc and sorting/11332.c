#include<stdio.h>
int main()
{
 long int n;
 long int t,r,d;
while((scanf("%ld",&n)) !=EOF)
{
   /// if(n>=0)
   /// {
        if(n==0)
    {
        break;
    }
    else if(n>0)
    {
    do
    {
    r=n%10;
    d=n/10;
    n=r+d;
    } while(d !=0);
    printf("%ld\n",n);
  ///  }
    }


}

return 0;
}


/*while(t!=0)
{
u=t%10;
sum=sum+u;
printf("%d ",sum);
t=t/10;
}
printf("\nsummation of digits :%d",sum);*/


