#include<stdio.h>
int main()
{
    long int a,b,c,k,m,l;

    while((scanf("%ld %ld %ld",&a,&b,&c)) !=EOF)
    {

        if(a!=0 || b!=0 || c!=0)
         {
            k=a*a;
            m=b*b;
            l=c*c;

        if(k==m+l)
        {
            printf("right\n");
        }
       else if(m==k+l)
        {
            printf("right\n");
        }
        else if(l==m+k)
        {
            printf("right\n");
        }
        else
            printf("wrong\n");


         }


    }

    return 0;
}
