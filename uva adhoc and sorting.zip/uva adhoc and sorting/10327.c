#include<stdio.h>
int main()
{
   int a[1050],n,i,j,t,k=0;
    while(scanf("%d",&n) !=EOF)
        { k=0;

                    for(i=0;i<n;i++)
                    {
                        scanf("%d",&a[i]);
                    }
                    for(i=1;i<n;i++)
                    {
                        for(j=n-1;j>=i;j--)
                        {
                            if(a[j-1]>a[j])
                            {
                            t=a[j-1];
                            a[j-1]=a[j];
                            a[j]=t;
                            k++;
                            }
                        }
                    }
                    printf("Minimum exchange operations : %d\n",k);


    }
    return 0;
}
