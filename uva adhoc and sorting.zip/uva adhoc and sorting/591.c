#include<stdio.h>
int main()
{
    int n,a[100],i,j=1,sum,moves,average;
    while((scanf("%d",&n))!=EOF)
    {
        if(n==0)
        {
            break;
        }
        if(n>=1 && n<=50)
        {
        sum=0;
        moves=0;
        for(i=1;i<=n;i++)
        {
            scanf("%d",&a[i]);
            if(a[i] >=1 && a[i]<=100)
            sum=sum+a[i];
        }

        average=sum/n;
        for(i=1;i<=n;i++)
        {
            if(a[i]>average)
            {
                moves+=(a[i]-average);
            }
        }
        printf("Set #%d\n",j);
        printf("The minimum number of moves is %d\n",moves);
        j++;
        }


    }



    return 0;
}
