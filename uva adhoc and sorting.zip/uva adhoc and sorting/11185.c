#include<stdio.h>
int main()
{
   long long int a[1000],d,n,t=0,i,dv,mo;
    while(scanf("%lld",&d) !=EOF)
    {
        if(d<0)
        {
            break;
        }

       else if (d==0)
       {
           printf("0");
       }
     else
     {
           t=0;
                while(d>0)
        {

            mo=d%3;
            a[t]=mo;
            d=d/3;

            t++;
        }
     }
        for(i=t-1;i>=0;i--)
        {
            printf("%lld",a[i]);
        }
        printf("\n");
    }
return 0;
}
