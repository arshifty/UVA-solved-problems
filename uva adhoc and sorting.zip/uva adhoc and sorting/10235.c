#include<stdio.h>
#include<math.h>
int main()
{
    long long int n,i,j,flag,m4,mod,ice,p;
    while(scanf("%lld",&n)!=EOF)
    {

         flag=0;
         p=n;
            for(i=2; i<=pow(n,0.5); i++)
        {
            if(n%i==0)
            {
                flag=1;
                break;
            }

        }

        if(flag==0)
        {
            m4=0;
            while(n)
            {
                mod=n%10;
                m4=m4*10+mod;
                n=n/10;
            }

            ice=0;
            for(i=2; i<=pow(m4,0.5); i++)
            {
                if(m4%i==0)
                {
                    ice=1;
                    break;
                }



            }
            if(ice==0 && p!=m4)
            {
                printf("%lld is emirp.\n",p);
            }
            else
                printf("%lld is prime.\n",p);
        }
        else
            printf("%lld is not prime.\n",p);


    }



    return 0;
}
