#include<stdio.h>
#include<math.h>

int main()
{
    double a,b,n,m,j,i,k,sum;
    while((scanf("%lf %lf",&a,&b))!=EOF)
    {
        sum=0;
        if(a==0 && b==0)
        {
            break;
        }

               for(i=a;i<=b;i++)
               {
               k=sqrt(i);
               m=floor(k);
               j=ceil(k);
                           if(m==j)
                           {
                              sum+=1;
                           }
               }
               printf("%.0lf\n",sum);




    }


    return 0;
}
