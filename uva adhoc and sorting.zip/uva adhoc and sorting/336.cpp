/*#include<bits/stdc++.h>
using namespace std;
vector<long long>G[100000];
long long cnt,p=1;
int bfs(long long s,long long ttl)
{
    long long num=0,i,k,m=1;
    queue<long long>Q;
    long visit[100000]={0};
    long long dis[100000]={0};
    Q.push(s);
    visit[s]=1;
    dis[s]=0;
    while(! Q.empty()){
        long long u=Q.front();
        Q.pop();
        for(i=0; i<G[u].size(); i++){
            long long v=G[u][i];
            if(!visit[v]){
                Q.push(v);
                visit[v]=1;
                dis[v]=dis[u]+1;
            }
        }
    }
    for(k=0; k<99990; k++){
        if(dis[k]<=ttl && dis[k] >0){
            m++;
        }
    }
    if(G[s].size()==0){
        m=0;
    }
    cout<<"Case "<<p++<<": "<<cnt-m<<" nodes not reachable from node "<<s<<" with TTL = "<<ttl<<"."<<endl;
}
int main()
{

    long long n,x,y,s,ttl,d,i;
    while(cin>>n){
        if(n==0){
            return 0;
        }
        long long total[100000]={0};
        cnt=0;
        memset(G,NULL,sizeof(G));
        for(i=0; i<n; i++){
            cin>>x>>y;
            G[x].push_back(y);
            G[y].push_back(x);
            total[x]=1;
            total[y]=1;
        }
        for(d=0; d<99990; d++){
            if(total[d]==1){
                cnt++;
            }
        }
        while(cin>>s>>ttl){
            if(s==0 && ttl==0){
                break;
            }
            bfs(s,ttl);
        }
    }
    return 0;
}

*/

#include<bits/stdc++.h>
using namespace std;
vector<long long>G[100000];
long long cnt,p=1;

int bfs(long long cnt,long long source,long long ttl)
{
long long num=0,i,k,m=1;
long visited[100000]={0};
long long distance[100000]={0};
queue<long long>Q;
Q.push(source);
visited[source]=1;
distance[source]=0;

while(!Q.empty())
{
    long long u=Q.front();
    Q.pop();

    for(i=0;i<G[u].size();i++)
    {
        int v=G[u][i];
        if(!visited[v])
        {
           Q.push(v);
           visited[v]=1;
           distance[v]=distance[u]+1;

        }
    }
}

for(k=0;k<99990;k++)
{
   if(distance[k]<=ttl && distance[k]>0)
   {
   m++;
   }
}
printf("m= %d\n",m);

if(G[source].size()==0)
{
    m=0;
}

printf("\n\nvisited : %lld \n\n",m);

 cout<<"Case "<<p++<<": "<<(cnt-m)<<" nodes not reachable from node "<<source<<" with TTL = "<<ttl<<"."<<endl;



}





int main()
{
    long long i,edge,x,y,source ,cnt, ttl;
   while(cin>>edge)
   {


    if(edge==0)
    {
        return 0;
    }

    long long total[100000]={0};
    cnt=0;


    memset(G,NULL,sizeof(G));
    for(i=0;i<edge;i++)
    {
       cin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
        total[x]=1;
        total[y]=1;

    }

    long long d;
    for(d=0;d<99990;d++)
    {
        if(total[d]==1)
        {
            cnt++;
        }
    }
    printf("\nTotal node : %d \n",cnt);

    while(cin>>source>>ttl)
    {
        if(source==0 && ttl==0)
        {
            break;
        }
       bfs(cnt,source,ttl);
    }

   }
    return 0;
}







/*
vector<int>G[100000];
int visited[100000]={0};
int see[100000];
int unvisited[1000000];



void bfs(vector<int>G[100000],int source)
{
    int i;
queue<int>Q;
   Q.push(source);
visited[source]=1;
printf("source : %d\n\n traverse graph from source ::  \n",source);


while(!Q.empty())
{
    int u=Q.front();
    for(i=0;i<G[u].size();i++)
    {
        int v=G[u][i];
        if(visited[v]==0)
        {
            Q.push(v);
            visited[v]=1;


            printf("%d ",v/);
        }


    }
    Q.pop();

}

}

int main()
{
    int edge,i,x,y,s;
    scanf("%d",&edge);
    for(i=0;i<edge;i++)
    {
        scanf("%d %d",&x,&y);
        G[x].push_back(y);
        G[y].push_back(x);
    }
    printf("\nEnter source :\n");
    scanf("%d",&s);


    bfs(G,s);


}
*/
