#include<stdio.h>
int main()
{
    int n,t,i,j,a[100];
    while(scanf("%d",&n)!=EOF)
    {
     for(i=1;i<=n;i++)
     {
         scanf("%d",&t);
         for(j=0;j<t;j++)
         {
          scanf("%d",&a[j]);
         }


         printf("Case %d: %d\n",i,a[j/2]);
     }
    }
    return 0;
}
