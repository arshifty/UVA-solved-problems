#include<stdio.h>
int main()
{
    int cd,cm,cy,bd,bm,by,d,m,y,t,l,age;
    while((scanf("%d",&t)) !=EOF)
     {
    printf("\n");
    for(l=1;l<=t;l++)
    {
    scanf("%d/%d/%d",&cd,&cm,&cy);
    scanf("%d/%d/%d",&bd,&bm,&by);

    d=cd-bd;
    if(cd<bd)
    {
     d=(cd+30)-bd;
     m=cm-(bm+1);
     if(cm<bm)
     {
         m=(cm+12)-bm;
         y=cy-(by+1);
     }
     else
        y=cy-by;
    }

    if(cm>bm)
    {
        m=cm-bm;
        y=cy-by;
    }
    if(cm==bm)
    {
        y=cy-(by+1);
    }

    age=y;
    if(age<0)
    {
        printf("Case #%d: Invalid birth date\n",l);
    }
    else if(age>130)
    {
         printf("Case #%d: Check birth date\n",l);
    }
    else
          printf("Case #%d: %d\n",l,age);


    }



     }

    return 0;
}
