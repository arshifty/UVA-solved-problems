#include<stdio.h>

int main()
{
    int t,n,i,sum,ans;
    scanf("%d",&t);

    while(t--)
    {
          scanf("%d",&n);
          if(n>=-1000 && n<=1000)
          {
              sum=((((((n*567)/9)+7492)*235)/47)-498);
          ans=((sum/10)%10);
          if(ans<0){
                ans=(ans/(-1));

          }
          printf("%d\n",ans);
          }

    }


    return 0;
}
