#include<stdio.h>
int main()
{
    double h,m,angle,hr,mr;

    while((scanf("%lf:%lf",&h,&m))!=EOF)
    {
        if(h==0 && m==0)
        {
            break;
        }
        angle=((30*h)-(5.5*m));
        if(angle<0)
            angle*=(-1);
        if(angle>180)
            angle=360-angle;


        printf("%.3lf\n",angle);

    }


    return 0;
}
